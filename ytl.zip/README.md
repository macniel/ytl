# NodeVideo

This project was generated with [angular-cli](https://github.com/angular/angular-cli) version 1.0.0-beta.28.3.

## Requisites

This project uses ffmpeg and a installation needs to be available

## Development server
Run `ng serve` for the frontend server. Navigate to `http://localhost:4200/`.
Run `node index.js` for the backend server. It will create endpoints on `http://localhost:3000/`.