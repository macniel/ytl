/// <reference path="globals/chai/index.d.ts" />
/// <reference path="globals/fluent-ffmpeg/index.d.ts" />
/// <reference path="globals/mongoose/index.d.ts" />
/// <reference path="globals/seneca/index.d.ts" />
